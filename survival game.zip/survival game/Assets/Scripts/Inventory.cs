using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class Inventory : MonoBehaviour
{
    public Image inventoryImage; // Reference to the Image component for inventory display
    private List<Sprite> collectedFoodSprites = new List<Sprite>(); // Store collected food sprites

    // You may need to create references to the sprite images for each food item here.

    public PlayerHealth playerHealth;

    private void Start()
    {
        playerHealth = GetComponent<PlayerHealth>(); // Get the PlayerHealth component from the player
    }

    public void AddFood(Sprite foodSprite)
    {
        collectedFoodSprites.Add(foodSprite);
        UpdateInventoryImage();
    }

    public void ConsumeFood(Sprite foodSprite, int healthValue)
    {
        if (collectedFoodSprites.Contains(foodSprite))
        {
            collectedFoodSprites.Remove(foodSprite);
            UpdateInventoryImage();
            playerHealth.Heal(healthValue); // Heal the player when consuming food
        }
    }

    private void UpdateInventoryImage()
    {
        // You'll need to update the inventoryImage sprite based on the collectedFoodSprites list.
        // This will involve iterating through the list and updating the displayed sprites accordingly.
        // Example: inventoryImage.sprite = collectedFoodSprites[0]; // Assuming you have only one slot for inventory.
    }
}
