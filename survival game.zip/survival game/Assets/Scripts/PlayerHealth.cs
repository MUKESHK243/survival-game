using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    public float maxHealth = 100f;
    private float currentHealth = 10f;
    public Slider healthSlider;

    private void Start()
    {
        maxHealth = 100; // Set your desired maximum health value
        currentHealth = (int)(maxHealth * 0.10f); // Set starting health to 10% of max health
        UpdateHealthUI();
    }

    private void UpdateHealthUI()
    {
        float healthPercent = (float)currentHealth / maxHealth;
        healthSlider.value = healthPercent;
    }

    public void Heal(float healAmount)
    {
        currentHealth += healAmount;
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
        UpdateHealthUI();
    }


    
}
