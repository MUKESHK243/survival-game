using UnityEngine;

public class TomatoCollectible : MonoBehaviour
{
    private PlayerHealth playerHealth;

    private void Start()
    {
        playerHealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerHealth.Heal(5f); // Heal 5% of health for Tomato
            Debug.Log("Collected Tomato!!!");
            Destroy(gameObject);
        }
    }
}
