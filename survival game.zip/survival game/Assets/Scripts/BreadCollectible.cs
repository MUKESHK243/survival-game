using UnityEngine;

public class BreadCollectible : MonoBehaviour
{
    private PlayerHealth playerHealth;

    private void Start()
    {
        playerHealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerHealth.Heal(10f); // Heal 10% of health for Bread
            Debug.Log("Collected Bread!!!");
            Destroy(gameObject);
        }
    }
}
